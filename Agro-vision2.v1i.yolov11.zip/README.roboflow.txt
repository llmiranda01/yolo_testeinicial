
Agro-vision2 - v1 2026-09-30 12:44am
==============================

This dataset was exported via roboflow.com on September 30, 2026 at 3:45 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 54 images.
Agro-vision2 are annotated in YOLOv11 format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


